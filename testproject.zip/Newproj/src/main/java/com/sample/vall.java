package com.sample;

import java.util.HashMap;

public class vall {
	public  static class value{
    	
    	public  int a=12;
    	public  int b=2;
    	public static  int result=1;
    	public static HashMap map= new HashMap();
		public int getA() {
			return a;
		}
		public void setA(int a) {
			this.a = a;
		}
		public int getB() {
			return b;
		}
		public void setB(int b) {
			this.b = b;
		}
		public   int getResult() {
			return result;
		}
		public static void setResult(int result) {
			value.result = result;
		}
    	
		
		
    }

}
